package org.zerock.service;

import java.util.List;

import org.zerock.domain.Menu;

public interface MenuService {
	
	public List<Menu> getAllmenus();
	
}
