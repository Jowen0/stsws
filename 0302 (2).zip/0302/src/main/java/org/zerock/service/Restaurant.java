package org.zerock.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Service
@ToString
@RequiredArgsConstructor
public class Restaurant {
	
	
	private final Chef chef;
	//의존성 주입
	//생성자 주입 / setter 주입 / 필드 주입
	//setter 주입
	
}
