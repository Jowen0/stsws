package org.zerock.service;

import org.springframework.stereotype.Component;

@Component
public class Chef {
	
	
	
}
