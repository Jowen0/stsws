package org.tufcookie.time.service;

public interface TimeService {
	
	String getTime();
	
	String getTime2();
	
}
